

<?php


echo" $_POST["textco"]"





?>
