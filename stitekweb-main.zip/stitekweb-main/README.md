# FLASK WEB stitekweb
- folder venv pu into /home/USER/Documents/web/
- folder tisk-stitku put into /home/USER/Documents/
- extract zip folder www.zip into /var/ - apache2 required
- start app run webapp.py
- FLASK IP 192.168.0.120:5000
- tiskarna.ppd is for CUPS settitn ZEBRA printer

# CHANGE LOG
<03.05.2022 - vsechno :D

03.05.2022 - úprava manuálního zadávání štítku - min/max délka vstupu, povolení zadávat jen čisla ...
	- úprava 2index - min/max délka vstupu qr
	- úprava wevapp.py - pokud je qr chybný obsahuje mezeru, tak se presmeruje na error_qr.html
	- úprava zakladu pro vytvorení stitku, st.jpg - odstravení šedivé a zostreni vzhledu

04.05.2022 - úprava 2index - vylepšený vzhled (hamburger menu)
	- oprava data.xlsx 1fk7 N/M opraveo na A/E
	- úprava stitek.html - lepší tabulka, stejná jako na 2index
	- přidání barev na záložku /UKA - odmeřování, Z a datum výroby

