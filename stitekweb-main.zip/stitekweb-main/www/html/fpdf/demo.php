<!DOCTYPE html>
<html>
<body>

<h1>The Window Object</h1>
<h2>The open() Method</h2>

<p>Click the button to open a new browser window.</p>

<button onclick="myFunction()">Try it</button>

<script>
function myFunction() {
  window.open("https://www.w3schools.com");
}
</script>


</body>
</html>
